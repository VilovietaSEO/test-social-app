// src/pages/create-post.tsx

import React, { useState } from 'react';
import { NextPage } from 'next';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/router';
import { PlatformSelector, PostEditor, MediaUploader, Scheduler, RepeatOptions, FirstCommentInput, LivePreview } from '../components/post';
import { Button } from '../components/ui/Button';

const CreatePost: NextPage = () => {
  const { data: session } = useSession();
  const router = useRouter();
  const [content, setContent] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [media, setMedia] = useState<File[]>([]);
  const [schedule, setSchedule] = useState<Date | null>(null);
  const [repeatInterval, setRepeatInterval] = useState<number | null>(null);
  const [firstComment, setFirstComment] = useState('');

  if (!session) {
    router.push('/login');
    return null;
  }

  const handlePostCreation = async () => {
    // Logic to handle post creation
    console.log('Creating post with:', {
      content,
      selectedPlatforms,
      media,
      schedule,
      repeatInterval,
      firstComment,
    });
    // TODO: Implement API call to create post
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Create New Post</h1>
      <PlatformSelector selectedPlatforms={selectedPlatforms} setSelectedPlatforms={setSelectedPlatforms} />
      <PostEditor content={content} setContent={setContent} />
      <MediaUploader media={media} setMedia={setMedia} />
      <FirstCommentInput firstComment={firstComment} setFirstComment={setFirstComment} />
      <Scheduler schedule={schedule} setSchedule={setSchedule} />
      <RepeatOptions repeatInterval={repeatInterval} setRepeatInterval={setRepeatInterval} />
      <LivePreview content={content} media={media} platforms={selectedPlatforms} />
      <Button onClick={handlePostCreation} className="mt-4">Create Post</Button>
    </div>
  );
};

export default CreatePost;