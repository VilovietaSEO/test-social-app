// src/pages/password-reset/[token].tsx

import { useState } from 'react';
import { useRouter } from 'next/router';
import axios from 'axios';
import { Input, Button, Notification } from '../../components/ui';

const PasswordReset = () => {
  const router = useRouter();
  const { token } = router.query;
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handlePasswordReset = async () => {
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);
    setError('');
    setMessage('');

    try {
      const response = await axios.post('/api/auth/password-reset', {
        token,
        newPassword: password,
      });

      setMessage(response.data.message);
      setTimeout(() => {
        router.push('/login');
      }, 3000);
    } catch (err) {
      setError(err.response?.data?.error || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-2">
      <h1 className="text-2xl font-bold">Reset Password</h1>
      <div className="w-full max-w-md mt-4">
        <Input
          type="password"
          placeholder="New Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <Input
          type="password"
          placeholder="Confirm New Password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
        />
        <Button onClick={handlePasswordReset} loading={loading}>
          Reset Password
        </Button>
        {message && <Notification type="success" message={message} />}
        {error && <Notification type="error" message={error} />}
      </div>
    </div>
  );
};

export default PasswordReset;