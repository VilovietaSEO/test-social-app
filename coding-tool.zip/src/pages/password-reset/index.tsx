// src/pages/password-reset/index.tsx

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { apiClient } from '../../utils/apiClient';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';

interface PasswordResetFormData {
  email: string;
}

const PasswordResetPage: React.FC = () => {
  const { register, handleSubmit, formState: { errors } } = useForm<PasswordResetFormData>();
  const [message, setMessage] = useState<string | null>(null);

  const onSubmit = async (data: PasswordResetFormData) => {
    try {
      await apiClient.post('/api/auth/password-reset-request', data);
      setMessage('If an account with that email exists, a password reset link has been sent.');
    } catch (error) {
      setMessage('An error occurred. Please try again later.');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10">
      <h1 className="text-2xl font-bold mb-4">Password Reset</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <Input
            type="email"
            label="Email"
            {...register('email', { required: 'Email is required' })}
            error={errors.email?.message}
          />
        </div>
        <Button type="submit" className="w-full">Send Password Reset Link</Button>
      </form>
      {message && <p className="mt-4 text-center">{message}</p>}
    </div>
  );
};

export default PasswordResetPage;