// src/pages/404.tsx

import React from 'react';
import Link from 'next/link';
import MainLayout from '../components/layout/MainLayout';

const Custom404: React.FC = () => {
  return (
    <MainLayout>
      <div className="flex flex-col items-center justify-center min-h-screen py-2">
        <h1 className="text-4xl font-bold text-gray-800">404 - Page Not Found</h1>
        <p className="mt-4 text-lg text-gray-600">
          Oops! The page you are looking for does not exist.
        </p>
        <Link href="/">
          <a className="mt-6 px-4 py-2 text-white bg-blue-600 rounded hover:bg-blue-700">
            Go back to Home
          </a>
        </Link>
      </div>
    </MainLayout>
  );
};

export default Custom404;