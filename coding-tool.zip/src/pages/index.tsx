// src/pages/index.tsx

import React from 'react';
import Head from 'next/head';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100">
      <Head>
        <title>Welcome to Our Social Media Tool</title>
        <meta name="description" content="A minimalist tool for managing social media posts across multiple platforms." />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main className="flex flex-col items-center justify-center w-full flex-1 px-20 text-center">
        <h1 className="text-6xl font-bold">
          Welcome to <span className="text-blue-600">Our Social Media Tool</span>
        </h1>

        <p className="mt-3 text-2xl">
          Get started by logging in or registering an account.
        </p>

        <div className="flex mt-6">
          <a href="/login" className="px-4 py-2 mx-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            Login
          </a>
          <a href="/register" className="px-4 py-2 mx-2 bg-gray-300 text-black rounded hover:bg-gray-400">
            Register
          </a>
        </div>
      </main>

      <footer className="flex items-center justify-center w-full h-24 border-t">
        <p className="text-gray-500">© 2023 Our Social Media Tool. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default HomePage;