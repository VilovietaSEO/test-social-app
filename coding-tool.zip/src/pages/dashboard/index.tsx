// src/pages/dashboard/index.tsx

import React from 'react';
import MainLayout from '../../components/layout/MainLayout';
import Card from '../../components/ui/Card';
import Loader from '../../components/ui/Loader';
import { useAuth } from '../../hooks/useAuth';

const Dashboard: React.FC = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return <Loader />;
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Card title="Create New Post" link="/create-post">
            <p>Quickly create and schedule a new post for your social media accounts.</p>
          </Card>
          <Card title="View Drafts" link="/drafts">
            <p>Manage your saved drafts and prepare them for publishing.</p>
          </Card>
          <Card title="Scheduled Posts" link="/scheduled-posts">
            <p>Review and manage your scheduled posts.</p>
          </Card>
          <Card title="Published Posts" link="/published-posts">
            <p>View your published posts and their performance.</p>
          </Card>
          <Card title="Media Library" link="/media">
            <p>Access and manage your media files.</p>
          </Card>
          <Card title="Settings" link="/settings">
            <p>Update your profile, connected accounts, and preferences.</p>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default Dashboard;