import { NextApiRequest, NextApiResponse } from 'next';
import { getSession } from 'next-auth/react';
import formidable from 'formidable';
import fs from 'fs';
import { supabase } from '../../../lib/supabaseClient'; // Assuming supabaseClient is set up

// Disable Next.js's default body parser
export const config = {
  api: {
    bodyParser: false,
  },
};

const uploadHandler = async (req: NextApiRequest, res: NextApiResponse) => {
  const session = await getSession({ req });

  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const form = new formidable.IncomingForm();
  form.uploadDir = './uploads'; // Temporary directory for uploads
  form.keepExtensions = true;

  form.parse(req, async (err, fields, files) => {
    if (err) {
      return res.status(500).json({ error: 'Error parsing the files' });
    }

    const file = files.file as formidable.File;
    const filePath = file.path;
    const fileName = file.name;

    try {
      // Read the file from the temporary directory
      const fileData = fs.readFileSync(filePath);

      // Upload the file to Supabase Storage
      const { data, error } = await supabase.storage
        .from('media')
        .upload(`uploads/${session.user.id}/${fileName}`, fileData, {
          cacheControl: '3600',
          upsert: false,
        });

      if (error) {
        throw error;
      }

      // Remove the file from the temporary directory
      fs.unlinkSync(filePath);

      return res.status(200).json({ url: data.Key });
    } catch (error) {
      return res.status(500).json({ error: 'Error uploading the file' });
    }
  });
};

export default uploadHandler;