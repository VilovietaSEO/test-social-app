import { NextApiRequest, NextApiResponse } from 'next';
import { getSession } from 'next-auth/react';
import prisma from '../../../lib/prisma';

// Handler for managing connected social media accounts
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getSession({ req });

  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const userId = session.user.id;

  switch (req.method) {
    case 'GET':
      // Retrieve connected accounts
      try {
        const accounts = await prisma.socialAccount.findMany({
          where: { userId },
        });
        return res.status(200).json(accounts);
      } catch (error) {
        return res.status(500).json({ error: 'Failed to retrieve connected accounts' });
      }

    case 'POST':
      // Connect a new social media account
      const { platform, accessToken, refreshToken, expiresAt } = req.body;
      try {
        const newAccount = await prisma.socialAccount.create({
          data: {
            userId,
            platform,
            accessToken,
            refreshToken,
            expiresAt: new Date(expiresAt),
          },
        });
        return res.status(201).json(newAccount);
      } catch (error) {
        return res.status(500).json({ error: 'Failed to connect account' });
      }

    case 'DELETE':
      // Disconnect a social media account
      const { accountId } = req.body;
      try {
        await prisma.socialAccount.delete({
          where: { id: accountId },
        });
        return res.status(204).end();
      } catch (error) {
        return res.status(500).json({ error: 'Failed to disconnect account' });
      }

    default:
      res.setHeader('Allow', ['GET', 'POST', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}