// src/pages/api/user/profile.ts

import { NextApiRequest, NextApiResponse } from 'next';
import { getSession } from 'next-auth/react';
import prisma from '../../../lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getSession({ req });

  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const userEmail = session.user?.email;

  if (!userEmail) {
    return res.status(400).json({ error: 'User email not found' });
  }

  switch (req.method) {
    case 'GET':
      try {
        const user = await prisma.user.findUnique({
          where: { email: userEmail },
          select: {
            id: true,
            name: true,
            email: true,
            profilePictureUrl: true,
          },
        });

        if (!user) {
          return res.status(404).json({ error: 'User not found' });
        }

        return res.status(200).json(user);
      } catch (error) {
        return res.status(500).json({ error: 'Internal server error' });
      }

    case 'PUT':
      try {
        const { name, profilePictureUrl } = req.body;

        const updatedUser = await prisma.user.update({
          where: { email: userEmail },
          data: {
            name,
            profilePictureUrl,
          },
        });

        return res.status(200).json(updatedUser);
      } catch (error) {
        return res.status(500).json({ error: 'Internal server error' });
      }

    default:
      res.setHeader('Allow', ['GET', 'PUT']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}