import { NextApiRequest, NextApiResponse } from 'next';
import { getSession } from 'next-auth/react';
import prisma from '../../../lib/prisma';

// Handler for creating or updating a draft
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getSession({ req });

  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const userId = session.user.id;

  if (req.method === 'POST') {
    const { id, content, platforms } = req.body;

    try {
      let draft;
      if (id) {
        // Update existing draft
        draft = await prisma.draft.update({
          where: { id },
          data: { content, platforms },
        });
      } else {
        // Create new draft
        draft = await prisma.draft.create({
          data: {
            userId,
            content,
            platforms,
          },
        });
      }

      return res.status(200).json(draft);
    } catch (error) {
      console.error('Error creating/updating draft:', error);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
  } else {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }
}