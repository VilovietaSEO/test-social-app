// src/pages/api/posts/published.ts

import { NextApiRequest, NextApiResponse } from 'next';
import { getSession } from 'next-auth/react';
import prisma from '../../../lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getSession({ req });

  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const userId = session.user.id;

  try {
    if (req.method === 'GET') {
      // Fetch published posts for the authenticated user
      const publishedPosts = await prisma.publishedPost.findMany({
        where: { userId },
        orderBy: { postedAt: 'desc' },
      });

      return res.status(200).json(publishedPosts);
    } else {
      res.setHeader('Allow', ['GET']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
    }
  } catch (error) {
    console.error('Error fetching published posts:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
}