// src/pages/api/posts/scheduled.ts

import { NextApiRequest, NextApiResponse } from 'next';
import { getSession } from 'next-auth/react';
import prisma from '../../../lib/prisma';
import { withAuth } from '../../../middlewares/withAuth';
import { validateRequest } from '../../../server/api/middlewares/validateRequest';
import { schedulePostSchema } from '../../../server/api/schemas/postSchema';
import { Job, Queue } from 'bullmq';
import { postQueue } from '../../../server/jobs';

const handler = async (req: NextApiRequest, res: NextApiResponse) => {
  const session = await getSession({ req });

  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  switch (req.method) {
    case 'POST':
      try {
        // Validate request body
        const { content, platforms, scheduledAt, repeatInterval, repeatEnd } = await validateRequest(
          req.body,
          schedulePostSchema
        );

        // Create a scheduled post in the database
        const scheduledPost = await prisma.scheduledPost.create({
          data: {
            userId: session.user.id,
            content,
            platforms,
            scheduledAt: new Date(scheduledAt),
            repeatInterval,
            repeatEnd: repeatEnd ? new Date(repeatEnd) : null,
            status: 'scheduled',
          },
        });

        // Add job to the queue
        const job: Job = await postQueue.add('publishPost', {
          postId: scheduledPost.id,
          userId: session.user.id,
        }, {
          delay: new Date(scheduledAt).getTime() - Date.now(),
          repeat: repeatInterval ? { every: repeatInterval * 24 * 60 * 60 * 1000 } : undefined,
        });

        return res.status(201).json({ scheduledPost, jobId: job.id });
      } catch (error) {
        return res.status(400).json({ error: error.message });
      }

    default:
      res.setHeader('Allow', ['POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
};

export default withAuth(handler);