import { NextApiRequest, NextApiResponse } from 'next';
import { getSession } from 'next-auth/react';
import prisma from '../../../lib/prisma';
import { validateRequest } from '../../../middlewares/validateRequest';
import { postSchema } from '../../../server/api/schemas/postSchema';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getSession({ req });

  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { id } = req.query;

  if (typeof id !== 'string') {
    return res.status(400).json({ error: 'Invalid post ID' });
  }

  switch (req.method) {
    case 'GET':
      return handleGetPost(req, res, id);
    case 'PUT':
      return handleUpdatePost(req, res, id);
    case 'DELETE':
      return handleDeletePost(req, res, id);
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}

async function handleGetPost(req: NextApiRequest, res: NextApiResponse, id: string) {
  try {
    const post = await prisma.post.findUnique({
      where: { id },
    });

    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    return res.status(200).json(post);
  } catch (error) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function handleUpdatePost(req: NextApiRequest, res: NextApiResponse, id: string) {
  try {
    const validation = validateRequest(req.body, postSchema);

    if (!validation.isValid) {
      return res.status(400).json({ error: validation.errors });
    }

    const updatedPost = await prisma.post.update({
      where: { id },
      data: req.body,
    });

    return res.status(200).json(updatedPost);
  } catch (error) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function handleDeletePost(req: NextApiRequest, res: NextApiResponse, id: string) {
  try {
    await prisma.post.delete({
      where: { id },
    });

    return res.status(204).end();
  } catch (error) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}