// src/pages/api/posts/index.ts

import { NextApiRequest, NextApiResponse } from 'next';
import { getSession } from 'next-auth/react';
import prisma from '../../../lib/prisma';
import { withAuth } from '../../../middlewares/withAuth';

const handler = async (req: NextApiRequest, res: NextApiResponse) => {
  const session = await getSession({ req });

  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const userId = session.user.id;

  switch (req.method) {
    case 'POST':
      try {
        const { content, platforms, firstComment } = req.body;

        // Validate input
        if (!content || !platforms || platforms.length === 0) {
          return res.status(400).json({ error: 'Invalid input' });
        }

        // Create a new post
        const post = await prisma.post.create({
          data: {
            userId,
            content,
            platforms,
            firstComment,
            status: 'draft', // Default status
          },
        });

        return res.status(201).json(post);
      } catch (error) {
        console.error('Error creating post:', error);
        return res.status(500).json({ error: 'Internal server error' });
      }

    default:
      res.setHeader('Allow', ['POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
};

export default withAuth(handler);