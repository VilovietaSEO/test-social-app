// src/server/api/middlewares/validateRequest.ts

import { NextApiRequest, NextApiResponse } from 'next';
import { AnySchema } from 'yup';

/**
 * Middleware to validate API request bodies using Yup schemas.
 * @param schema - The Yup schema to validate against.
 * @returns A middleware function for Next.js API routes.
 */
export const validateRequest = (schema: AnySchema) => {
  return async (req: NextApiRequest, res: NextApiResponse, next: Function) => {
    try {
      await schema.validate(req.body, { abortEarly: false });
      next();
    } catch (error) {
      res.status(400).json({ error: error.errors });
    }
  };
};