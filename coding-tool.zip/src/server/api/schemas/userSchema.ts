import * as Yup from 'yup';

// Validation schema for user registration
export const userRegistrationSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email format').required('Email is required'),
  password: Yup.string()
    .min(8, 'Password must be at least 8 characters long')
    .required('Password is required'),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref('password'), null], 'Passwords must match')
    .required('Confirm password is required'),
});

// Validation schema for user login
export const userLoginSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email format').required('Email is required'),
  password: Yup.string().required('Password is required'),
});

// Validation schema for updating user profile
export const userProfileSchema = Yup.object().shape({
  name: Yup.string().max(50, 'Name cannot exceed 50 characters'),
  profilePictureUrl: Yup.string().url('Invalid URL format'),
});

// Validation schema for password reset request
export const passwordResetRequestSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email format').required('Email is required'),
});

// Validation schema for password reset confirmation
export const passwordResetConfirmationSchema = Yup.object().shape({
  token: Yup.string().required('Token is required'),
  newPassword: Yup.string()
    .min(8, 'Password must be at least 8 characters long')
    .required('New password is required'),
  confirmNewPassword: Yup.string()
    .oneOf([Yup.ref('newPassword'), null], 'Passwords must match')
    .required('Confirm new password is required'),
});