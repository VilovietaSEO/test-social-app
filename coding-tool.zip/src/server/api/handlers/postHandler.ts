// src/server/api/handlers/postHandler.ts

import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '../../lib/prisma';
import { validateRequest } from '../middlewares/validateRequest';
import { postSchema } from '../schemas/postSchema';
import { socialMediaService } from '../../services/socialMediaService';

// Handler for creating a new post
export const createPost = async (req: NextApiRequest, res: NextApiResponse) => {
  try {
    // Validate the request body against the post schema
    const validatedData = await validateRequest(req.body, postSchema);

    // Create a new post in the database
    const post = await prisma.post.create({
      data: {
        content: validatedData.content,
        platforms: validatedData.platforms,
        userId: req.user.id, // Assuming user ID is available in the request
        scheduledAt: validatedData.scheduledAt,
        repeatInterval: validatedData.repeatInterval,
        firstComment: validatedData.firstComment,
      },
    });

    // If the post is scheduled, add it to the job queue
    if (post.scheduledAt) {
      await socialMediaService.schedulePost(post);
    } else {
      // Otherwise, publish immediately
      await socialMediaService.publishPost(post);
    }

    res.status(201).json({ post });
  } catch (error) {
    console.error('Error creating post:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

// Handler for updating an existing post
export const updatePost = async (req: NextApiRequest, res: NextApiResponse) => {
  try {
    const { id } = req.query;

    // Validate the request body against the post schema
    const validatedData = await validateRequest(req.body, postSchema);

    // Update the post in the database
    const post = await prisma.post.update({
      where: { id: Number(id) },
      data: {
        content: validatedData.content,
        platforms: validatedData.platforms,
        scheduledAt: validatedData.scheduledAt,
        repeatInterval: validatedData.repeatInterval,
        firstComment: validatedData.firstComment,
      },
    });

    res.status(200).json({ post });
  } catch (error) {
    console.error('Error updating post:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

// Handler for deleting a post
export const deletePost = async (req: NextApiRequest, res: NextApiResponse) => {
  try {
    const { id } = req.query;

    // Delete the post from the database
    await prisma.post.delete({
      where: { id: Number(id) },
    });

    res.status(204).end();
  } catch (error) {
    console.error('Error deleting post:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};