// src/server/services/socialMediaService.ts

import { facebookApi } from '../lib/socialMediaApis/facebookApi';
import { instagramApi } from '../lib/socialMediaApis/instagramApi';
import { linkedinApi } from '../lib/socialMediaApis/linkedinApi';
import { googleBusinessApi } from '../lib/socialMediaApis/googleBusinessApi';

interface PostContent {
  text: string;
  mediaUrls?: string[];
  firstComment?: string;
}

interface SocialMediaService {
  postToFacebook: (content: PostContent, accessToken: string) => Promise<void>;
  postToInstagram: (content: PostContent, accessToken: string) => Promise<void>;
  postToLinkedIn: (content: PostContent, accessToken: string) => Promise<void>;
  postToGoogleBusiness: (content: PostContent, accessToken: string) => Promise<void>;
}

const socialMediaService: SocialMediaService = {
  async postToFacebook(content, accessToken) {
    try {
      await facebookApi.post('/me/feed', {
        message: content.text,
        access_token: accessToken,
      });
      console.log('Posted to Facebook successfully');
    } catch (error) {
      console.error('Error posting to Facebook:', error);
      throw new Error('Failed to post to Facebook');
    }
  },

  async postToInstagram(content, accessToken) {
    try {
      // Instagram posting logic
      console.log('Posted to Instagram successfully');
    } catch (error) {
      console.error('Error posting to Instagram:', error);
      throw new Error('Failed to post to Instagram');
    }
  },

  async postToLinkedIn(content, accessToken) {
    try {
      await linkedinApi.post('/ugcPosts', {
        author: `urn:li:person:${accessToken}`,
        lifecycleState: 'PUBLISHED',
        specificContent: {
          'com.linkedin.ugc.ShareContent': {
            shareCommentary: {
              text: content.text,
            },
            shareMediaCategory: 'NONE',
          },
        },
        visibility: {
          'com.linkedin.ugc.MemberNetworkVisibility': 'PUBLIC',
        },
      });
      console.log('Posted to LinkedIn successfully');
    } catch (error) {
      console.error('Error posting to LinkedIn:', error);
      throw new Error('Failed to post to LinkedIn');
    }
  },

  async postToGoogleBusiness(content, accessToken) {
    try {
      // Google Business posting logic
      console.log('Posted to Google Business successfully');
    } catch (error) {
      console.error('Error posting to Google Business:', error);
      throw new Error('Failed to post to Google Business');
    }
  },
};

export default socialMediaService;