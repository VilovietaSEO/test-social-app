// src/server/services/mediaService.ts

import { createClient } from '@supabase/supabase-js';
import { v4 as uuidv4 } from 'uuid';

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL || '';
const supabaseKey = process.env.SUPABASE_KEY || '';
const supabase = createClient(supabaseUrl, supabaseKey);

export const uploadMedia = async (file: File, userId: string) => {
  try {
    const fileName = `${uuidv4()}-${file.name}`;
    const { data, error } = await supabase.storage
      .from('media')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (error) {
      throw new Error(`Failed to upload media: ${error.message}`);
    }

    return data;
  } catch (error) {
    console.error('Error uploading media:', error);
    throw error;
  }
};

export const getMediaUrl = (fileName: string) => {
  try {
    const { publicURL, error } = supabase.storage.from('media').getPublicUrl(fileName);

    if (error) {
      throw new Error(`Failed to get media URL: ${error.message}`);
    }

    return publicURL;
  } catch (error) {
    console.error('Error getting media URL:', error);
    throw error;
  }
};

export const deleteMedia = async (fileName: string) => {
  try {
    const { error } = await supabase.storage.from('media').remove([fileName]);

    if (error) {
      throw new Error(`Failed to delete media: ${error.message}`);
    }

    return true;
  } catch (error) {
    console.error('Error deleting media:', error);
    throw error;
  }
};