// src/server/lib/socialMediaApis/facebookApi.ts

import axios from 'axios';

const FACEBOOK_GRAPH_API_URL = 'https://graph.facebook.com/v12.0';

interface FacebookApiConfig {
  accessToken: string;
  pageId: string;
}

export class FacebookApi {
  private accessToken: string;
  private pageId: string;

  constructor(config: FacebookApiConfig) {
    this.accessToken = config.accessToken;
    this.pageId = config.pageId;
  }

  /**
   * Publish a post to a Facebook Page.
   * @param message - The message content of the post.
   * @param link - Optional link to include in the post.
   * @returns The response from the Facebook API.
   */
  async publishPost(message: string, link?: string) {
    try {
      const response = await axios.post(
        `${FACEBOOK_GRAPH_API_URL}/${this.pageId}/feed`,
        {
          message,
          link,
          access_token: this.accessToken,
        }
      );
      return response.data;
    } catch (error) {
      console.error('Error publishing post to Facebook:', error);
      throw new Error('Failed to publish post to Facebook.');
    }
  }

  /**
   * Upload a photo to a Facebook Page.
   * @param photoUrl - The URL of the photo to upload.
   * @param caption - Optional caption for the photo.
   * @returns The response from the Facebook API.
   */
  async uploadPhoto(photoUrl: string, caption?: string) {
    try {
      const response = await axios.post(
        `${FACEBOOK_GRAPH_API_URL}/${this.pageId}/photos`,
        {
          url: photoUrl,
          caption,
          access_token: this.accessToken,
        }
      );
      return response.data;
    } catch (error) {
      console.error('Error uploading photo to Facebook:', error);
      throw new Error('Failed to upload photo to Facebook.');
    }
  }

  // Additional methods for other Facebook API interactions can be added here.
}