import React, { useState } from 'react';
import axios from 'axios';

interface MediaUploaderProps {
  onMediaSelect: (mediaUrls: string[]) => void;
}

const MediaUploader: React.FC<MediaUploaderProps> = ({ onMediaSelect }) => {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      setSelectedFiles(Array.from(event.target.files));
    }
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0) {
      setError('Please select files to upload.');
      return;
    }

    setUploading(true);
    setError(null);

    try {
      const formData = new FormData();
      selectedFiles.forEach((file) => formData.append('files', file));

      const response = await axios.post('/api/media/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      onMediaSelect(response.data.mediaUrls);
      setSelectedFiles([]);
    } catch (err) {
      setError('Failed to upload files. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="media-uploader">
      <input
        type="file"
        multiple
        accept="image/*,video/*"
        onChange={handleFileChange}
        className="file-input"
      />
      <button
        onClick={handleUpload}
        disabled={uploading}
        className="upload-button"
      >
        {uploading ? 'Uploading...' : 'Upload'}
      </button>
      {error && <p className="error-message">{error}</p>}
      <div className="preview">
        {selectedFiles.map((file, index) => (
          <div key={index} className="file-preview">
            <p>{file.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MediaUploader;