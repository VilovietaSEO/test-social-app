// src/components/ui/Icon.tsx

import React from 'react';
import { LucideIcon, LucideProps } from 'lucide-react';

interface IconProps extends LucideProps {
  name: string;
}

const Icon: React.FC<IconProps> = ({ name, ...props }) => {
  const LucideIconComponent = LucideIcon[name];

  if (!LucideIconComponent) {
    console.warn(`Icon "${name}" does not exist in Lucide Icons.`);
    return null;
  }

  return <LucideIconComponent {...props} />;
};

export default Icon;