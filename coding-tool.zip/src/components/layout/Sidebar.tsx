// src/components/layout/Sidebar.tsx

import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { HomeIcon, PostIcon, DraftIcon, SettingsIcon } from 'lucide-react'; // Example icons

const Sidebar: React.FC = () => {
  const router = useRouter();

  const menuItems = [
    { name: 'Dashboard', path: '/dashboard', icon: <HomeIcon /> },
    { name: 'Create Post', path: '/create-post', icon: <PostIcon /> },
    { name: 'Drafts', path: '/drafts', icon: <DraftIcon /> },
    { name: 'Settings', path: '/settings', icon: <SettingsIcon /> },
  ];

  return (
    <aside className="w-64 h-full bg-gray-800 text-white">
      <div className="p-4">
        <h2 className="text-lg font-bold">Menu</h2>
        <ul className="mt-4">
          {menuItems.map((item) => (
            <li key={item.name} className="mb-2">
              <Link href={item.path}>
                <a
                  className={`flex items-center p-2 rounded hover:bg-gray-700 ${
                    router.pathname === item.path ? 'bg-gray-700' : ''
                  }`}
                >
                  <span className="mr-3">{item.icon}</span>
                  {item.name}
                </a>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
};

export default Sidebar;