// src/components/layout/Header.tsx

import React from 'react';
import Link from 'next/link';
import { useSession, signOut } from 'next-auth/react';
import { Button } from '../ui/Button';

const Header: React.FC = () => {
  const { data: session } = useSession();

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-2 flex justify-between items-center">
        <Link href="/">
          <a className="text-xl font-bold text-gray-800">YourAppName</a>
        </Link>
        <nav className="flex items-center space-x-4">
          <Link href="/dashboard">
            <a className="text-gray-600 hover:text-gray-800">Dashboard</a>
          </Link>
          <Link href="/create-post">
            <a className="text-gray-600 hover:text-gray-800">Create Post</a>
          </Link>
          <Link href="/media">
            <a className="text-gray-600 hover:text-gray-800">Media Library</a>
          </Link>
          <Link href="/settings">
            <a className="text-gray-600 hover:text-gray-800">Settings</a>
          </Link>
          {session ? (
            <Button onClick={() => signOut()} className="text-gray-600 hover:text-gray-800">
              Sign Out
            </Button>
          ) : (
            <Link href="/login">
              <a className="text-gray-600 hover:text-gray-800">Login</a>
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;