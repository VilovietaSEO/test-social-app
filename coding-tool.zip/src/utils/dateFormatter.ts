// src/utils/dateFormatter.ts

/**
 * Formats a Date object into a readable string format.
 * @param date - The Date object to format.
 * @param options - Optional formatting options.
 * @returns A formatted date string.
 */
export function formatDate(
  date: Date,
  options?: Intl.DateTimeFormatOptions
): string {
  const defaultOptions: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short',
  };

  const formatOptions = { ...defaultOptions, ...options };
  return new Intl.DateTimeFormat('en-US', formatOptions).format(date);
}