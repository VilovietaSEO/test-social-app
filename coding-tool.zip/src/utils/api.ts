// src/utils/api.ts

import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';

// Create an instance of axios with default settings
const apiClient = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:3000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add authorization token if available
apiClient.interceptors.request.use(
  (config: AxiosRequestConfig) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle responses globally
apiClient.interceptors.response.use(
  (response: AxiosResponse) => response,
  (error) => {
    // Handle errors globally (e.g., log out user on 401)
    if (error.response?.status === 401) {
      // Handle unauthorized access
      console.error('Unauthorized access - logging out');
      // Optionally, redirect to login page
    }
    return Promise.reject(error);
  }
);

export default apiClient;