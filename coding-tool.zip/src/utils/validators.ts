// src/utils/validators.ts

import * as Yup from 'yup';

// Validation schema for user registration
export const registrationSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email address').required('Email is required'),
  password: Yup.string()
    .min(8, 'Password must be at least 8 characters')
    .required('Password is required'),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref('password'), null], 'Passwords must match')
    .required('Confirm password is required'),
});

// Validation schema for user login
export const loginSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email address').required('Email is required'),
  password: Yup.string().required('Password is required'),
});

// Validation schema for profile update
export const profileSchema = Yup.object().shape({
  name: Yup.string().max(50, 'Name cannot exceed 50 characters'),
  email: Yup.string().email('Invalid email address').required('Email is required'),
});

// Validation schema for post creation
export const postSchema = Yup.object().shape({
  content: Yup.string().required('Content is required'),
  platforms: Yup.array().of(Yup.string()).min(1, 'At least one platform must be selected'),
});

// Validation schema for media upload
export const mediaUploadSchema = Yup.object().shape({
  file: Yup.mixed().required('A file is required'),
});

export default {
  registrationSchema,
  loginSchema,
  profileSchema,
  postSchema,
  mediaUploadSchema,
};