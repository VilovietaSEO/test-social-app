// src/utils/constants.ts

// Application-wide constants

// API Endpoints
export const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:3000/api';

// Social Media Platform Names
export const PLATFORM_FACEBOOK = 'facebook';
export const PLATFORM_INSTAGRAM = 'instagram';
export const PLATFORM_LINKEDIN = 'linkedin';
export const PLATFORM_GOOGLE_BUSINESS = 'google_business';

// Default Pagination Settings
export const DEFAULT_PAGE_SIZE = 10;
export const DEFAULT_PAGE_NUMBER = 1;

// Date and Time Formats
export const DATE_FORMAT = 'YYYY-MM-DD';
export const TIME_FORMAT = 'HH:mm:ss';

// Stripe Configuration
export const STRIPE_PUBLIC_KEY = process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY || '';

// Error Messages
export const ERROR_GENERIC = 'An unexpected error occurred. Please try again later.';
export const ERROR_NETWORK = 'Network error. Please check your internet connection.';

// Success Messages
export const SUCCESS_POST_SCHEDULED = 'Your post has been successfully scheduled.';
export const SUCCESS_PROFILE_UPDATED = 'Your profile has been updated successfully.';

// Other Constants
export const MAX_UPLOAD_SIZE_MB = 10; // Maximum upload size in megabytes
export const SUPPORTED_IMAGE_FORMATS = ['image/jpeg', 'image/png', 'image/gif'];
export const SUPPORTED_VIDEO_FORMATS = ['video/mp4', 'video/webm'];