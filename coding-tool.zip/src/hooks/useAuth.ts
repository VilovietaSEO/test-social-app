// src/hooks/useAuth.ts

import { useContext, useEffect, useState } from 'react';
import { useSession, signIn, signOut } from 'next-auth/react';
import { AuthContext } from '../context/AuthContext';

interface UseAuthReturn {
  user: any;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

export const useAuth = (): UseAuthReturn => {
  const { data: session, status } = useSession();
  const { setUser } = useContext(AuthContext);
  const [loading, setLoading] = useState<boolean>(status === 'loading');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (status === 'authenticated') {
      setUser(session?.user || null);
    }
    setLoading(status === 'loading');
  }, [session, status, setUser]);

  const login = async (email: string, password: string) => {
    setLoading(true);
    setError(null);
    try {
      const result = await signIn('credentials', {
        redirect: false,
        email,
        password,
      });
      if (result?.error) {
        setError(result.error);
      }
    } catch (err) {
      setError('An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    signOut();
  };

  return {
    user: session?.user || null,
    loading,
    error,
    login,
    logout,
  };
};