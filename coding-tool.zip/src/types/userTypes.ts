// src/types/userTypes.ts

export interface User {
  id: string;
  email: string;
  name?: string;
  profilePictureUrl?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserProfile {
  id: string;
  email: string;
  name?: string;
  profilePictureUrl?: string;
}

export interface UserSettings {
  timezone: string;
  notifications: {
    emailAlerts: boolean;
  };
}

export interface SocialAccount {
  id: string;
  platform: string;
  accessToken: string;
  refreshToken?: string;
  expiresAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}