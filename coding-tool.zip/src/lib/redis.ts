// src/lib/redis.ts

import { Redis } from 'ioredis';

// Create a new Redis instance
const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: Number(process.env.REDIS_PORT) || 6379,
  password: process.env.REDIS_PASSWORD || undefined,
  tls: process.env.REDIS_TLS === 'true' ? {} : undefined, // Use TLS if specified
});

// Export the Redis instance for use in other parts of the application
export default redis;