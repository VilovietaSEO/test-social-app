// src/lib/stripe.ts

import Stripe from 'stripe';

// Initialize Stripe with your secret key
const stripeSecretKey = process.env.STRIPE_SECRET_KEY || '';

if (!stripeSecretKey) {
  throw new Error('Stripe secret key is not set in environment variables.');
}

const stripe = new Stripe(stripeSecretKey, {
  apiVersion: '2022-11-15', // Use the latest stable API version
});

export default stripe;